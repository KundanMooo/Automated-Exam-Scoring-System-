1) Paste all files in the same location.

2) Open Runfile.R code >Session>Set Working Directory> To Source File Location

3) run Runfile.R

4) An output file will be generated with the name myNamandjoboutput.
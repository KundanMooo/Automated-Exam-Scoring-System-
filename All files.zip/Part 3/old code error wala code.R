# This is a standalone R script for executing data processing.

# This is a standalone R script for executing data processing.

# Load the  package
library(tidyr)
library(readxl)
library(zoo)
library(dplyr)
library(readr)
library(stringr)

# Read the all sheet from the .xlsx file

file_path <- "Refrence file.xlsx"
sheet_names <- c("GEK", "EVA", "MOS", "CEA")
df_list <- list()
df11=data.frame()
for (sheet_name in sheet_names) {
  data <- read_excel(file_path, sheet = sheet_name)
  df <- data %>%
    mutate(across(everything(), ~ ifelse(is.na(.), first(.[!is.na(.)]), .)))
  df_list[[sheet_name]] <- df
  df11 <- rbind(df11, df)
  
}
View(df11)
df<-df11
dfkey <- do.call(rbind, df_list)
View(dfkey)
dfkeys <- dfkey[, c(2, 3, 5, 6)]
View(dfkeys)
colnames(dfkey)[colnames(dfkey) == "Actual Question"] <- "Actual_Question"
dfkey$UID <- sub("_\\d+$", "", dfkey$UID)# UID in proper format
View(dfkey)
dfkey11 <- data.frame(
  Primary_Key = paste(
    tolower(gsub(" ", "", dfkey$UID)),
    tolower(gsub(" ", "", dfkey$Options)),
    sep = ""
  ),
  dfkey$Marks,
  dfkey$Abb
)
View(dfkeys11)
dfkey11 <- dfkey11 %>%
  filter(dfkey.Marks != 0)
View(dfkey11)

#RAW file Data Preprocessing 
file_pathraw <- "Rawfile.csv"
dataraw <- read_csv(file_pathraw, locale = locale(encoding = "ISO-8859-1"))
dataraw <- dataraw[, -c(3:9)]
dataraw <- dataraw[, -c(1)]
# Transpose the dataframe
dataraw<- t(dataraw)
# Convert the transposed data back to a dataframe
dataraw <- as.data.frame(dataraw)
# renaming headers
colnames(dataraw) <- dataraw[1, ]
# Remove the first row (which is now the header row)
dataraw <- dataraw[-1, ]
# Made new column for "Question"
dataraw$Question <- rownames(dataraw)
# Extract pattern (1_Q_GEK_TP1_001)
dataraw$Question_ID <- str_extract(dataraw$Question, "\\(.*?\\)")
# making Question ID same as UID in refrence file
dataraw$Only_Question <- str_trim(str_replace(dataraw$Question, "\\(.*?\\)", ""))
dataraw$Question_ID <- sub(".*Q_", "Q_", dataraw$Question_ID)
dataraw$Question_ID <- sub("_\\d+\\)$", "", dataraw$Question_ID)
View(dataraw)


# Answer marked by Teachers stored in combined_df
teacher_dataframes <- list()

# Loop through each teacher and create data frames
for (i in 1:14) {
  teacher_col <- paste0("Teacher", i)
  df_name <- paste0("dft", i)
  df <- data.frame(
    Teacher_No = i,
    Primary_Key = paste(
      tolower(gsub(" ", "", dataraw$Question_ID)),
      tolower(gsub(" ", "", dataraw[[teacher_col]])),
      sep = ""
    )
  )
  teacher_dataframes[[df_name]] <- df
}
# Concatenate all data frames into a single data frame
combined_df <- do.call(rbind, teacher_dataframes)

# Markes scores by teacher in each question is stored in final_summary dataframe
summary_list <- list()

# Iterate through teacher numbers from 1 to 14
for (teacher_no in 1:14) {
  summary_result <- combined_df %>%
    filter(Teacher_No == teacher_no) %>%
    left_join(dfkey11, by = "Primary_Key") %>%
    group_by(dfkey.Abb) %>%
    summarise(
      summary_value = ifelse(dfkey.Abb %in% c("GEK", "CEA", "EVA"), sum(dfkey.Marks), 
                             ifelse(dfkey.Abb == "MOS", mean(dfkey.Marks), NA)),
      teacher_index = paste("Teacher", teacher_no, sep = " ")  # Add the teacher index column
    ) %>%
    na.omit() %>%
    distinct()
  
  # Add the summary_result to the summary_list
  summary_list[[as.character(teacher_no)]] <- summary_result
}

# Combine the summary dataframes in the summary_list into a single dataframe
final_summary <- do.call(rbind, summary_list)

# Print the final_summary dataframe

final_summary <- do.call(rbind, summary_list)

pivot_summary <- final_summary %>%
  pivot_wider(names_from = dfkey.Abb, values_from = summary_value) %>%
  replace_na(list(GEK = 0, CEA = 0, EVA = 0, MOS = 0))  # Replace NA with 0

View(pivot_summary)
# Generating outputfile csv
csv_file_path <- "myNamandjoboutput.csv"
# Write the pivot_summary dataframe to a CSV file
write.csv(pivot_summary, file = csv_file_path, row.names = FALSE)
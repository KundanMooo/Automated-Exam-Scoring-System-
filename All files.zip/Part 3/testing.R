library(readxl)
library(dplyr)

# Replace 'your_file.xlsx' with the actual path to your Excel file
file_path <- "Refrence file.xlsx"

# Read all sheets in the Excel file
sheet_names <- excel_sheets(file_path)

# Initialize an empty data frame to store concatenated data
concatenated_data <- data.frame()

# Loop through each sheet and concatenate data
for (sheet_name in sheet_names) {
  # Read data from the current sheet
  sheet_data <- read_excel(file_path, sheet = sheet_name)
  
  # Append the current sheet data to the concatenated data frame
  concatenated_data <- bind_rows(concatenated_data, sheet_data)
}

# Print the concatenated data
print(concatenated_data)

library(dplyr)

# Create a sample data frame
df <- data.frame(
  Height = c(1.75, 1.80, 1.68),
  Weight = c(70, 85, 62)
)

# Add a new column "BMI" using mutate
df_bmi <- df %>%
  mutate(BMI = Weight / (Height^2))

print(df_with_bmi)




# Create a sample matrix
mat <- matrix(
  c(80, 90, 75,
    70, 85, 92,
    60, 70, 80),
  ncol = 3,
  byrow = TRUE
)
df=data.frame(mat)
# Calculate row-wise averages using apply
row_averages <- apply(df, 1, mean)

print(row_averages)
View(row_averages)


COLOR1=c("q","f","g","g")
vv=as.factor(COLOR1)
print(vv)
library(zoo)
data=c(1,2,NA,3,10,NA)
df=data.frame(data)
View(df)
ff<-na.fill(df,mode(df[["data"]],na.rm=TRUE))
View(ff)


matrix_data <- matrix(1:12, nrow = 3)

row_sums <- apply(matrix_data, 1, sum)
print(row_sums)

student_data <- data.frame(
  Class = rep(1:10, each = 50),
  Marks = sample(50:100, 500, replace = TRUE)
)
class_sum <- student_data %>% group_by(Class)%>% summarise(mc=sum(Marks))

View(class_sum)

class_sum <- student_data %>%group_by(Class) %>%summarise(total_marks = sum(Marks))










